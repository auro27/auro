# Number Info Bot

Telegram bot for number lookup.

## Deploy on Railway / Koyeb

1. Upload this folder to GitHub
2. Connect to Railway or Koyeb
3. Add environment variable:
   - Key: `BOT_TOKEN`
   - Value: your bot token
4. Deploy

## Run locally

```bash
pip install -r requirements.txt
python bot.py
```
